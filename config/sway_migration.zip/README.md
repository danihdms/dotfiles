# Debian + Sway migration pack

This archive contains:
- `.config/sway/config`
- `.config/waybar/config.jsonc`
- `.config/waybar/style.css`

The Waybar setup is adapted from your Polybar:
- left: workspaces + active window
- center: full date
- right: battery + volume + keyboard + wifi + time
- same orange / beige / gray palette
- rounded grouped blocks to mimic your Polybar look

## 1. Install Debian
During Debian install:
- choose **Graphical install**
- at **Software selection**, uncheck every desktop environment
- keep only **standard system utilities**

## 2. Install packages
```bash
sudo apt update
sudo apt install \
  sway swaybg swayidle swaylock swaynag \
  waybar wl-clipboard grim slurp swappy \
  network-manager network-manager-gnome \
  pipewire wireplumber pavucontrol \
  rofi dunst brightnessctl kitty dex copyq \
  fonts-hack fonts-font-awesome
```

## 3. Enable services
```bash
sudo systemctl enable NetworkManager
```

## 4. Copy the files
From the extracted archive root:
```bash
mkdir -p ~/.config/sway ~/.config/waybar
cp .config/sway/config ~/.config/sway/config
cp .config/waybar/config.jsonc ~/.config/waybar/config.jsonc
cp .config/waybar/style.css ~/.config/waybar/style.css
```

## 5. Start Sway
From TTY:
```bash
sway
```

## 6. Important migration notes

### Screenshots
Your old binding:
```bash
$mod+p
```
now runs:
```bash
grim -g "$(slurp)" - | swappy -f -
```
This is the closest Wayland replacement to Flameshot.

### Wallpaper
Your wallpaper path is currently:
```bash
~/pictures/hyprland.png
```
If your real path is different, edit:
```bash
~/.config/sway/config
```

### Clipboard
Replace old X11 clipboard habits:
- `xclip` → `wl-copy` / `wl-paste`

Example:
```bash
echo test | wl-copy
wl-paste
```

### Rofi
Rofi usually works through XWayland. If you prefer a native Wayland launcher later, try:
```bash
sudo apt install wofi
```

### CopyQ
CopyQ may work imperfectly on Wayland. If it annoys you later, a native alternative is `cliphist`.

### nm-applet
This is included so your workflow stays close to your current setup.

## 7. Optional shell updates
In your shell config, these are worth changing:

### Remove auto-start X11
Delete this block from `~/.zshrc`:
```bash
if [ -z "${DISPLAY}" ] && [ "${XDG_VTNR}" -eq 1 ]; then
  startx 2> /dev/null
fi
```

### Update clipboard alias
Replace:
```bash
alias copy="xclip -selection xrandr"
```
with:
```bash
alias copy="wl-copy"
```

### Your `screen()` helper
Your current `screen()` function uses `xrandr`, so it will not work on Sway.
Use Sway output commands instead, for example:
```bash
swaymsg output HDMI-A-1 resolution 1920x1080 position 1920,0
```

## 8. Reload after edits
Inside Sway:
```bash
Mod+Shift+c
```

## 9. Files you may want to port later
These can be reused mostly as-is:
- `~/.config/kitty/kitty.conf`
- `~/.config/dunst/dunstrc`
- `~/.config/rofi/config.rasi`
- `~/.config/nvim/*`

## 10. Rounded corners / transparency
Vanilla Sway:
- no rounded corners
- no blur
- no Picom needed

If you want rounded corners and effects later, install `swayfx` instead of plain `sway`.
